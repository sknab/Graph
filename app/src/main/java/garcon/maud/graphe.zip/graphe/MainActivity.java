package garcon.maud.graphe;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;

/**
 * Created by Maud Garçon & Saly Knab on 10/10/2019.
 */

public class MainActivity extends AppCompatActivity {

    //Viriables de vue du graphe
    ImageView imageGraph;
    DrawableGraph graphView;
    private Graph graphe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //initialisation de la vue du graphe avec 9 noeuds
        graphe = new Graph(9);
        //on passe ça en drawable puis en imageview pour afficher une "image drawable"
        graphView = new DrawableGraph(graphe);
        imageGraph = findViewById(R.id.graph_image);
        imageGraph.setImageDrawable(graphView);



    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_ajouter) {
            //appeler la methode
            graphe.ajouterNoeud();
            //rafraichir l'affichage
            imageGraph.invalidate();
        }

        if (id == R.id.action_reset) {
            //supprime tout les noeuds
            graphe.getNoeuds().clear();
            //rafraichir
            imageGraph.invalidate();
        }
        return super.onOptionsItemSelected(item);
    }
}
