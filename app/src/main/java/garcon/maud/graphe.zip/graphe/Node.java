package garcon.maud.graphe;

import java.util.ArrayList;

/**
 * Created by Maud Garçon & Saly Knab on 10/10/2019.
 */

public class Node {
    //voisins = noeud avec qui le noeud courant à des arcs
    private ArrayList<Node> voisins;
    //position du noeud
    private int x;
    private int y;
    //couleur du noeud
    private String couleur;

    public Node(int x, int y, String couleur) {
        this.x = x;
        this.y = y;
        this.couleur = couleur;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }
}
