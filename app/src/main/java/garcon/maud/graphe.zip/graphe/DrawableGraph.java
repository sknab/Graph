package garcon.maud.graphe;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

/**
 * Created by Maud Garçon & Saly Knab on 10/10/2019.
 */

public class DrawableGraph extends Drawable {

    private Graph graphe;
    private int tailleNoeuds ;

    public DrawableGraph(Graph graphe) {
        this.graphe = graphe;
        tailleNoeuds = 100;
    }

    @Override
    public void draw(@NonNull Canvas canvas) {
        for (Node noeud : graphe.getNoeuds()) {
            //dessiner le rond
            canvas.drawRoundRect( noeud.getX(), noeud.getY(), noeud.getX() + tailleNoeuds, noeud.getY()+tailleNoeuds, tailleNoeuds/2, tailleNoeuds/2, new Paint());
        }

    }

    @Override
    public void setAlpha(int i) {

    }

    @Override
    public void setColorFilter(@Nullable ColorFilter colorFilter) {

    }

    @Override
    public int getOpacity() {
        return 0;
    }
}
