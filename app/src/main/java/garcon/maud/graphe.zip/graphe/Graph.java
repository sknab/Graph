package garcon.maud.graphe;

import java.util.ArrayList;

/**
 * Created by Maud Garçon & Saly Knab on 10/10/2019.
 */

public class Graph {
   private ArrayList<Node> noeuds;

    public Graph(int n) {
        //initialisation du tableau de noeuds
        noeuds = new ArrayList<>();
        for (int i = 0; i < n; i++){
            //intialisations des noeuds
            noeuds.add(new Node(120 * i,0, "noir"));
        }
    }

    public ArrayList<Node> getNoeuds() {
        return noeuds;
    }

    public void setNoeuds(ArrayList<Node> noeuds) {
        this.noeuds = noeuds;
    }

    public void ajouterNoeud(){
        //ajouter un noeud a tel et tel entroit
        noeuds.add(new Node( 300,300, "noir"));
    }
}

